import { Receipt } from "lucide-react";
import ReceiptForm from "@/components/receipt-form";
import ReceiptPreview from "@/components/receipt-preview";
import { useState } from "react";
import { ReceiptItem } from "@shared/schema";
import { nanoid } from "nanoid";

export interface ReceiptData {
  businessName: string;
  businessPhone: string;
  businessEmail: string;
  businessAddress: string;
  businessCountry: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  currency: string;
  items: ReceiptItem[];
  taxRate: number;
  taxAmount: number;
  discountType: "none" | "percentage" | "fixed";
  discountValue: number;
  discountAmount: number;
  notes: string;
  paymentMethod: "cash" | "bank_transfer" | "pos" | "mobile_money" | "stripe";
  paymentStatus: "pending" | "paid" | "failed" | "refunded";
}

export default function ReceiptGenerator() {
  const [receiptData, setReceiptData] = useState<ReceiptData>({
    businessName: "",
    businessPhone: "",
    businessEmail: "",
    businessAddress: "",
    businessCountry: "US",
    customerName: "",
    customerPhone: "",
    customerEmail: "",
    currency: "USD",
    items: [{ id: nanoid(), name: "", price: 0, quantity: 1 }],
    taxRate: 0,
    taxAmount: 0,
    discountType: "none",
    discountValue: 0,
    discountAmount: 0,
    notes: "",
    paymentMethod: "cash",
    paymentStatus: "pending",
  });

  const [generatedReceipt, setGeneratedReceipt] = useState<any>(null);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground shadow-lg no-print">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Receipt className="h-8 w-8" />
              <h1 className="text-2xl font-bold">Global Receipts</h1>
            </div>
            <div className="text-sm opacity-90">Worldwide Professional Receipt Generator</div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          <ReceiptForm 
            receiptData={receiptData}
            setReceiptData={setReceiptData}
            setGeneratedReceipt={setGeneratedReceipt}
          />
          <ReceiptPreview 
            receiptData={receiptData}
            generatedReceipt={generatedReceipt}
          />
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-muted border-t border-border mt-12 py-8 no-print">
        <div className="container mx-auto px-4 text-center text-muted-foreground">
          <p>&copy; 2024 Global Receipts. Worldwide professional receipt generation made simple.</p>
        </div>
      </footer>
    </div>
  );
}
