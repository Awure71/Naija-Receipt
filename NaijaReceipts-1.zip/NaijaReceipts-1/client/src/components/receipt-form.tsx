import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { Building, User, List, Plus, Trash2, CreditCard, Receipt, Globe, Minus, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertReceiptSchema, ReceiptItem } from "@shared/schema";
import { COUNTRIES, CURRENCIES, formatCurrency } from "@shared/global-config";
import { ReceiptData } from "@/pages/receipt-generator";
import { nanoid } from "nanoid";
import StripeCheckout from "@/components/stripe-checkout";

const formSchema = insertReceiptSchema.extend({
  businessEmail: z.string().email("Invalid email").optional().or(z.literal("")),
  customerEmail: z.string().email("Invalid email").optional().or(z.literal("")),
});

interface ReceiptFormProps {
  receiptData: ReceiptData;
  setReceiptData: (data: ReceiptData) => void;
  setGeneratedReceipt: (receipt: any) => void;
}

export default function ReceiptForm({ receiptData, setReceiptData, setGeneratedReceipt }: ReceiptFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showStripeCheckout, setShowStripeCheckout] = useState(false);
  const [pendingReceipt, setPendingReceipt] = useState<any>(null);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      businessName: "",
      businessPhone: "",
      businessEmail: "",
      businessAddress: "",
      businessCountry: "US",
      customerName: "",
      customerPhone: "",
      customerEmail: "",
      currency: "USD",
      items: [{ id: nanoid(), name: "", price: 0, quantity: 1 }],
      subtotal: "0",
      taxRate: "0",
      taxAmount: "0",
      discountType: "none",
      discountValue: "0",
      discountAmount: "0",
      total: "0",
      notes: "",
      paymentMethod: "cash",
      paymentStatus: "pending",
    },
  });

  const createReceiptMutation = useMutation({
    mutationFn: async (data: z.infer<typeof formSchema>) => {
      const response = await apiRequest("POST", "/api/receipts", data);
      return response.json();
    },
    onSuccess: (receipt) => {
      setGeneratedReceipt(receipt);
      
      // If payment method is stripe, show checkout modal
      if (receipt.paymentMethod === "stripe") {
        setPendingReceipt(receipt);
        setShowStripeCheckout(true);
      } else {
        toast({
          title: "Receipt Generated",
          description: `Receipt ${receipt.receiptNumber} has been created successfully.`,
        });
      }
      
      queryClient.invalidateQueries({ queryKey: ["/api/receipts"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to generate receipt",
        variant: "destructive",
      });
    },
  });

  const updatePaymentStatusMutation = useMutation({
    mutationFn: async ({ receiptId, paymentStatus, stripePaymentIntentId }: {
      receiptId: string;
      paymentStatus: string;
      stripePaymentIntentId?: string;
    }) => {
      const response = await apiRequest("PATCH", `/api/receipts/${receiptId}/payment`, {
        paymentStatus,
        stripePaymentIntentId,
      });
      return response.json();
    },
    onSuccess: (updatedReceipt) => {
      setGeneratedReceipt(updatedReceipt);
      setReceiptData({ ...receiptData, paymentStatus: updatedReceipt.paymentStatus });
      setShowStripeCheckout(false);
      setPendingReceipt(null);
      
      toast({
        title: "Payment Successful",
        description: `Receipt ${updatedReceipt.receiptNumber} has been paid successfully.`,
      });
      
      queryClient.invalidateQueries({ queryKey: ["/api/receipts"] });
    },
    onError: (error: any) => {
      toast({
        title: "Payment Update Failed",
        description: error.message || "Failed to update payment status",
        variant: "destructive",
      });
    },
  });

  const addItem = () => {
    const newItem: ReceiptItem = {
      id: nanoid(),
      name: "",
      price: 0,
      quantity: 1,
    };
    const updatedItems = [...receiptData.items, newItem];
    setReceiptData({ ...receiptData, items: updatedItems });
    form.setValue("items", updatedItems);
  };

  const removeItem = (itemId: string) => {
    const updatedItems = receiptData.items.filter(item => item.id !== itemId);
    setReceiptData({ ...receiptData, items: updatedItems });
    form.setValue("items", updatedItems);
    updateCalculations(updatedItems);
  };

  const updateItem = (itemId: string, field: "name" | "price" | "quantity", value: string | number) => {
    const updatedItems = receiptData.items.map(item => 
      item.id === itemId ? { ...item, [field]: value } : item
    );
    setReceiptData({ ...receiptData, items: updatedItems });
    form.setValue("items", updatedItems);
    if (field === "price" || field === "quantity") {
      updateCalculations(updatedItems);
    }
  };

  const incrementQuantity = (itemId: string) => {
    const item = receiptData.items.find(item => item.id === itemId);
    if (item) {
      const newQuantity = (item.quantity || 1) + 1;
      updateItem(itemId, "quantity", newQuantity);
    }
  };

  const decrementQuantity = (itemId: string) => {
    const item = receiptData.items.find(item => item.id === itemId);
    if (item) {
      const newQuantity = Math.max(1, (item.quantity || 1) - 1);
      updateItem(itemId, "quantity", newQuantity);
    }
  };

  const duplicateItem = (itemId: string) => {
    const item = receiptData.items.find(item => item.id === itemId);
    if (item) {
      const duplicatedItem: ReceiptItem = {
        id: nanoid(),
        name: item.name,
        price: item.price,
        quantity: item.quantity,
      };
      const updatedItems = [...receiptData.items, duplicatedItem];
      setReceiptData({ ...receiptData, items: updatedItems });
      form.setValue("items", updatedItems);
      updateCalculations(updatedItems);
      
      toast({
        title: "Item Duplicated",
        description: `${item.name || "Item"} has been duplicated successfully.`,
      });
    }
  };

  const updateCalculations = (items: ReceiptItem[], taxRate?: number, discountType?: string, discountValue?: number) => {
    const subtotal = items.reduce((sum, item) => {
      const itemTotal = (Number(item.price) || 0) * (Number(item.quantity) || 1);
      return sum + itemTotal;
    }, 0);
    
    const currentTaxRate = taxRate !== undefined ? taxRate : receiptData.taxRate;
    const currentDiscountType = discountType !== undefined ? discountType : receiptData.discountType;
    const currentDiscountValue = discountValue !== undefined ? discountValue : receiptData.discountValue;
    
    let discountAmount = 0;
    if (currentDiscountType === "percentage") {
      discountAmount = (subtotal * currentDiscountValue) / 100;
    } else if (currentDiscountType === "fixed") {
      discountAmount = Math.min(currentDiscountValue, subtotal);
    }
    
    const subtotalAfterDiscount = subtotal - discountAmount;
    const taxAmount = (subtotalAfterDiscount * currentTaxRate) / 100;
    const total = subtotalAfterDiscount + taxAmount;
    
    form.setValue("subtotal", subtotal.toFixed(2));
    form.setValue("taxAmount", taxAmount.toFixed(2));
    form.setValue("discountAmount", discountAmount.toFixed(2));
    form.setValue("total", total.toFixed(2));
    
    setReceiptData({ 
      ...receiptData, 
      items,
      taxAmount: Number(taxAmount.toFixed(2)),
      discountAmount: Number(discountAmount.toFixed(2))
    });
  };

  const handlePaymentSuccess = (paymentIntentId: string) => {
    if (pendingReceipt) {
      updatePaymentStatusMutation.mutate({
        receiptId: pendingReceipt.id,
        paymentStatus: "paid",
        stripePaymentIntentId: paymentIntentId,
      });
    }
  };

  const handlePaymentCancel = () => {
    setShowStripeCheckout(false);
    setPendingReceipt(null);
    
    toast({
      title: "Payment Cancelled",
      description: "Payment was cancelled. You can try again or use a different payment method.",
    });
  };

  const onSubmit = (data: z.infer<typeof formSchema>) => {
    if (data.items.length === 0) {
      toast({
        title: "Validation Error",
        description: "Please add at least one item to the receipt.",
        variant: "destructive",
      });
      return;
    }

    const hasEmptyItems = data.items.some(item => !item.name.trim() || item.price <= 0 || (item.quantity || 0) <= 0);
    if (hasEmptyItems) {
      toast({
        title: "Validation Error",
        description: "Please ensure all items have a name, valid price, and quantity greater than 0.",
        variant: "destructive",
      });
      return;
    }

    createReceiptMutation.mutate(data);
  };

  const formatCurrencyDisplay = (amount: number) => {
    const country = COUNTRIES[receiptData.businessCountry];
    const locale = country?.locale || 'en-US';
    return formatCurrency(amount, receiptData.currency, locale);
  };

  const handleCountryChange = (countryCode: string) => {
    const country = COUNTRIES[countryCode];
    if (country) {
      const newTaxRate = country.defaultTaxRate;
      setReceiptData({ 
        ...receiptData, 
        businessCountry: countryCode,
        currency: country.currency,
        taxRate: newTaxRate
      });
      form.setValue("businessCountry", countryCode);
      form.setValue("currency", country.currency);
      form.setValue("taxRate", newTaxRate.toString());
      updateCalculations(receiptData.items, newTaxRate);
    }
  };

  const subtotal = receiptData.items.reduce((sum, item) => {
    const itemTotal = (Number(item.price) || 0) * (Number(item.quantity) || 1);
    return sum + itemTotal;
  }, 0);

  return (
    <>
    <Card className="form-section">
      <CardContent className="p-6 space-y-6">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-semibold text-foreground mb-2">Generate New Receipt</h2>
          <p className="text-muted-foreground">Create professional receipts in seconds</p>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Business Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-foreground border-b border-border pb-2 flex items-center">
                <Building className="mr-2 h-5 w-5 text-primary" />
                Business Information
              </h3>
              
              <FormField
                control={form.control}
                name="businessName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Business Name*</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Enter business name" 
                        data-testid="input-business-name"
                        {...field}
                        onChange={(e) => {
                          field.onChange(e);
                          setReceiptData({ ...receiptData, businessName: e.target.value });
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="businessPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone*</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="e.g. +234 800 123 4567" 
                          data-testid="input-business-phone"
                          {...field}
                          onChange={(e) => {
                            field.onChange(e);
                            setReceiptData({ ...receiptData, businessPhone: e.target.value });
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="businessEmail"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input 
                          type="email"
                          placeholder="business@example.com" 
                          data-testid="input-business-email"
                          {...field}
                          onChange={(e) => {
                            field.onChange(e);
                            setReceiptData({ ...receiptData, businessEmail: e.target.value });
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Country and Currency Selection */}
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-foreground border-b border-border pb-2 flex items-center">
                  <Globe className="mr-2 h-4 w-4 text-primary" />
                  Location & Currency
                </h4>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="businessCountry"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Country*</FormLabel>
                        <Select
                          onValueChange={(value) => {
                            field.onChange(value);
                            handleCountryChange(value);
                          }}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger data-testid="select-business-country">
                              <SelectValue placeholder="Select country" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {Object.values(COUNTRIES).map((country) => (
                              <SelectItem key={country.code} value={country.code}>
                                {country.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="currency"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Currency*</FormLabel>
                        <Select
                          onValueChange={(value) => {
                            field.onChange(value);
                            setReceiptData({ ...receiptData, currency: value });
                          }}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger data-testid="select-currency">
                              <SelectValue placeholder="Select currency" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {Object.values(CURRENCIES).map((currency) => (
                              <SelectItem key={currency.code} value={currency.code}>
                                {currency.symbol} {currency.code} - {currency.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <FormField
                control={form.control}
                name="businessAddress"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Address (Optional)</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Business address" 
                        rows={2}
                        data-testid="textarea-business-address"
                        {...field}
                        onChange={(e) => {
                          field.onChange(e);
                          setReceiptData({ ...receiptData, businessAddress: e.target.value });
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Customer Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-foreground border-b border-border pb-2 flex items-center">
                <User className="mr-2 h-5 w-5 text-accent" />
                Customer Information
              </h3>
              
              <div className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="customerName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Customer Name (Optional)</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Customer name" 
                          data-testid="input-customer-name"
                          {...field}
                          onChange={(e) => {
                            field.onChange(e);
                            setReceiptData({ ...receiptData, customerName: e.target.value });
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="customerPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Customer Phone (Optional)</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Customer phone" 
                          data-testid="input-customer-phone"
                          {...field}
                          onChange={(e) => {
                            field.onChange(e);
                            setReceiptData({ ...receiptData, customerPhone: e.target.value });
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="customerEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Customer Email (Optional)</FormLabel>
                    <FormControl>
                      <Input 
                        type="email"
                        placeholder="customer@example.com" 
                        data-testid="input-customer-email"
                        {...field}
                        onChange={(e) => {
                          field.onChange(e);
                          setReceiptData({ ...receiptData, customerEmail: e.target.value });
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Items Section */}
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-border pb-2">
                <h3 className="text-lg font-medium text-foreground flex items-center">
                  <List className="mr-2 h-5 w-5 text-secondary" />
                  Items
                </h3>
                <Button 
                  type="button"
                  onClick={addItem}
                  className="bg-primary hover:bg-primary/90"
                  data-testid="button-add-item"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Item
                </Button>
              </div>
              
              <div className="space-y-3">
                {receiptData.items.map((item, index) => (
                  <div key={item.id} className="bg-muted p-4 rounded-md border border-border">
                    <div className="grid grid-cols-12 gap-3 items-end">
                      <div className="col-span-4">
                        <Label className="text-sm font-medium text-foreground mb-1 block">Item Name</Label>
                        <Input 
                          placeholder="Item description"
                          value={item.name}
                          onChange={(e) => updateItem(item.id, "name", e.target.value)}
                          data-testid={`input-item-name-${index}`}
                        />
                      </div>
                      <div className="col-span-2">
                        <Label className="text-sm font-medium text-foreground mb-1 block">Quantity</Label>
                        <div className="flex items-center border border-input rounded-md">
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0 border-0 hover:bg-muted"
                            onClick={() => decrementQuantity(item.id)}
                            disabled={(item.quantity || 1) <= 1}
                            data-testid={`button-decrease-quantity-${index}`}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <Input 
                            type="number"
                            min="1"
                            value={item.quantity || 1}
                            onChange={(e) => updateItem(item.id, "quantity", parseInt(e.target.value) || 1)}
                            className="border-0 text-center h-8 focus-visible:ring-0 focus-visible:ring-offset-0"
                            data-testid={`input-item-quantity-${index}`}
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0 border-0 hover:bg-muted"
                            onClick={() => incrementQuantity(item.id)}
                            data-testid={`button-increase-quantity-${index}`}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                      <div className="col-span-2">
                        <Label className="text-sm font-medium text-foreground mb-1 block">Unit Price ({CURRENCIES[receiptData.currency]?.symbol || '$'})</Label>
                        <Input 
                          type="number"
                          placeholder="0.00"
                          step="0.01"
                          min="0"
                          value={item.price || ""}
                          onChange={(e) => updateItem(item.id, "price", parseFloat(e.target.value) || 0)}
                          data-testid={`input-item-price-${index}`}
                        />
                      </div>
                      <div className="col-span-2">
                        <Label className="text-sm font-medium text-foreground mb-1 block">Line Total</Label>
                        <div className="h-9 px-3 py-2 bg-background border border-input rounded-md text-sm font-medium text-muted-foreground flex items-center">
                          {formatCurrencyDisplay((item.price || 0) * (item.quantity || 1))}
                        </div>
                      </div>
                      <div className="col-span-2 flex gap-2">
                        <Button 
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => duplicateItem(item.id)}
                          data-testid={`button-duplicate-item-${index}`}
                          className="flex-1"
                          title="Duplicate item"
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button 
                          type="button"
                          variant="destructive"
                          size="sm"
                          onClick={() => removeItem(item.id)}
                          data-testid={`button-remove-item-${index}`}
                          className="flex-1"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Subtotal Display */}
              <div className="bg-muted p-4 rounded-md border border-border">
                <div className="flex justify-between items-center text-lg font-medium">
                  <span>Subtotal:</span>
                  <span data-testid="text-subtotal">{formatCurrencyDisplay(subtotal)}</span>
                </div>
              </div>
            </div>

            {/* Tax & Discount */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-foreground border-b border-border pb-2">
                Tax & Discount
              </h3>
              
              <div className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="taxRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{COUNTRIES[receiptData.businessCountry]?.taxName || "Tax"} Rate (%)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number"
                          placeholder="0"
                          step="0.01"
                          min="0"
                          max="100"
                          data-testid="input-tax-rate"
                          {...field}
                          onChange={(e) => {
                            const value = parseFloat(e.target.value) || 0;
                            field.onChange(e.target.value);
                            setReceiptData({ ...receiptData, taxRate: value });
                            updateCalculations(receiptData.items, value);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex items-end">
                  <div className="w-full">
                    <Label className="text-sm font-medium text-foreground mb-2 block">Tax Amount</Label>
                    <div className="h-10 px-3 py-2 bg-background border border-input rounded-md text-sm flex items-center font-medium">
                      {formatCurrencyDisplay(receiptData.taxAmount || 0)}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="grid md:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="discountType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Discount Type</FormLabel>
                      <Select 
                        onValueChange={(value) => {
                          field.onChange(value);
                          setReceiptData({ ...receiptData, discountType: value as any });
                          updateCalculations(receiptData.items, undefined, value);
                        }}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-discount-type">
                            <SelectValue placeholder="None" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">None</SelectItem>
                          <SelectItem value="percentage">Percentage</SelectItem>
                          <SelectItem value="fixed">Fixed Amount</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="discountValue"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        {receiptData.discountType === "percentage" ? "Discount (%)" : "Discount Amount"}
                      </FormLabel>
                      <FormControl>
                        <Input 
                          type="number"
                          placeholder="0"
                          step="0.01"
                          min="0"
                          disabled={receiptData.discountType === "none"}
                          data-testid="input-discount-value"
                          {...field}
                          onChange={(e) => {
                            const value = parseFloat(e.target.value) || 0;
                            field.onChange(e.target.value);
                            setReceiptData({ ...receiptData, discountValue: value });
                            updateCalculations(receiptData.items, undefined, undefined, value);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex items-end">
                  <div className="w-full">
                    <Label className="text-sm font-medium text-foreground mb-2 block">Total Discount</Label>
                    <div className="h-10 px-3 py-2 bg-background border border-input rounded-md text-sm flex items-center font-medium">
                      -{formatCurrencyDisplay(receiptData.discountAmount || 0)}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-primary/10 p-4 rounded-md border border-primary/20">
                <div className="flex justify-between items-center text-xl font-bold text-primary">
                  <span>Total:</span>
                  <span data-testid="text-total">{formatCurrencyDisplay(
                    subtotal - (receiptData.discountAmount || 0) + (receiptData.taxAmount || 0)
                  )}</span>
                </div>
              </div>
            </div>
            
            {/* Notes */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-foreground border-b border-border pb-2">
                Additional Notes
              </h3>
              
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes / Terms & Conditions (Optional)</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Enter any additional notes, terms, or special instructions..."
                        className="min-h-[100px] resize-none"
                        data-testid="input-notes"
                        {...field}
                        onChange={(e) => {
                          field.onChange(e);
                          setReceiptData({ ...receiptData, notes: e.target.value });
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Payment Method */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-foreground border-b border-border pb-2 flex items-center">
                <CreditCard className="mr-2 h-5 w-5 text-accent" />
                Payment Method
              </h3>
              
              <FormField
                control={form.control}
                name="paymentMethod"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormControl>
                      <RadioGroup
                        onValueChange={(value) => {
                          field.onChange(value);
                          setReceiptData({ ...receiptData, paymentMethod: value as any });
                        }}
                        defaultValue={field.value}
                        className="grid grid-cols-2 md:grid-cols-4 gap-3"
                      >
                        {[
                          { value: "cash", label: "Cash" },
                          { value: "bank_transfer", label: "Bank Transfer" },
                          { value: "pos", label: "POS" },
                          { value: "mobile_money", label: "Mobile Money" },
                          { value: "stripe", label: "Credit Card" },
                        ].map((method) => (
                          <div key={method.value} className="flex items-center p-3 border border-border rounded-md cursor-pointer hover:bg-muted transition-colors">
                            <RadioGroupItem 
                              value={method.value} 
                              id={method.value}
                              data-testid={`radio-payment-${method.value}`}
                            />
                            <Label htmlFor={method.value} className="ml-2 text-sm cursor-pointer">
                              {method.label}
                            </Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Total and Action */}
            <div className="space-y-4">
              <div className="bg-primary/10 border border-primary/20 p-4 rounded-md">
                <div className="flex justify-between items-center text-xl font-semibold">
                  <span>Total Amount:</span>
                  <span className="text-primary" data-testid="text-total">{formatCurrencyDisplay(subtotal)}</span>
                </div>
              </div>
              
              <Button 
                type="submit"
                className="w-full bg-accent hover:bg-accent/90 text-accent-foreground py-3 text-lg font-medium shadow-lg"
                disabled={createReceiptMutation.isPending}
                data-testid="button-generate-receipt"
              >
                {createReceiptMutation.isPending ? (
                  "Generating..."
                ) : (
                  <>
                    <Receipt className="mr-2 h-5 w-5" />
                    Generate Receipt
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>

    {/* Stripe Checkout Dialog */}
    <Dialog open={showStripeCheckout} onOpenChange={setShowStripeCheckout}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Complete Payment</DialogTitle>
        </DialogHeader>
        {pendingReceipt && (
          <StripeCheckout
            receiptId={pendingReceipt.id}
            amount={parseFloat(pendingReceipt.total)}
            currency={pendingReceipt.currency}
            onPaymentSuccess={handlePaymentSuccess}
            onCancel={handlePaymentCancel}
          />
        )}
      </DialogContent>
    </Dialog>
    </>
  );
}
