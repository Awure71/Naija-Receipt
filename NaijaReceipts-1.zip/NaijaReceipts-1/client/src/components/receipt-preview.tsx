import { Printer, Share2, QrCode } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ReceiptData } from "@/pages/receipt-generator";
import { COUNTRIES, formatCurrency } from "@shared/global-config";
import { useEffect, useState, useRef } from "react";
import QRCode from "qrcode";
import { useToast } from "@/hooks/use-toast";

interface ReceiptPreviewProps {
  receiptData: ReceiptData;
  generatedReceipt: any;
}

export default function ReceiptPreview({ receiptData, generatedReceipt }: ReceiptPreviewProps) {
  const { toast } = useToast();
  const [qrCode, setQrCode] = useState<string>("");
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const formatCurrencyDisplay = (amount: number | string) => {
    const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
    const country = COUNTRIES[receiptData.businessCountry || 'US'];
    const locale = country?.locale || 'en-US';
    const currency = receiptData.currency || 'USD';
    return formatCurrency(numAmount || 0, currency, locale);
  };

  const formatDate = (date: Date | string) => {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    const country = COUNTRIES[receiptData.businessCountry || 'US'];
    const locale = country?.locale || 'en-US';
    return dateObj.toLocaleDateString(locale, {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatTime = (date: Date | string) => {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    const country = COUNTRIES[receiptData.businessCountry || 'US'];
    const locale = country?.locale || 'en-US';
    return dateObj.toLocaleTimeString(locale, {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  useEffect(() => {
    if (generatedReceipt?.id) {
      const receiptUrl = `${window.location.origin}?receipt=${generatedReceipt.id}`;
      QRCode.toDataURL(receiptUrl, {
        width: 150,
        margin: 1,
      }).then(setQrCode);
    }
  }, [generatedReceipt]);

  const handlePrint = () => {
    window.print();
  };

  const handleShare = async () => {
    const shareData = {
      title: `Receipt ${generatedReceipt?.receiptNumber || 'Preview'}`,
      text: `Receipt from ${receiptData.businessName}\nTotal: ${formatCurrencyDisplay(totalAmount)}`,
      url: window.location.href,
    };

    if (navigator.share && navigator.canShare(shareData)) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          toast({
            title: "Share failed",
            description: "Unable to share this receipt",
            variant: "destructive",
          });
        }
      }
    } else {
      try {
        await navigator.clipboard.writeText(window.location.href);
        toast({
          title: "Link copied!",
          description: "Receipt link has been copied to clipboard",
        });
      } catch (err) {
        toast({
          title: "Error",
          description: "Unable to copy link",
          variant: "destructive",
        });
      }
    }
  };

  const paymentMethodLabels = {
    cash: "Cash",
    bank_transfer: "Bank Transfer",
    pos: "POS",
    mobile_money: "Mobile Money",
    stripe: "Credit Card"
  };

  const subtotal = receiptData.items.reduce((sum, item) => {
    const itemTotal = (Number(item.price) || 0) * (Number(item.quantity) || 1);
    return sum + itemTotal;
  }, 0);

  const discountAmount = receiptData.discountAmount || 0;
  const taxAmount = receiptData.taxAmount || 0;
  const totalAmount = subtotal - discountAmount + taxAmount;

  const displayData = generatedReceipt || receiptData;
  const currentDate = generatedReceipt ? new Date(generatedReceipt.createdAt) : new Date();
  const country = COUNTRIES[receiptData.businessCountry || 'US'];

  return (
    <Card className="receipt-paper">
      <CardContent className="p-8">
        <div className="max-w-sm mx-auto">
          {/* Receipt Header */}
          <div className="text-center mb-6 border-b-2 border-border pb-4">
            <h2 className="text-xl font-bold text-foreground mb-2" data-testid="text-business-name">
              {displayData.businessName || "Business Name"}
            </h2>
            <div className="text-sm text-muted-foreground space-y-1">
              {displayData.businessPhone && (
                <div data-testid="text-business-phone">{displayData.businessPhone}</div>
              )}
              {displayData.businessEmail && (
                <div data-testid="text-business-email">{displayData.businessEmail}</div>
              )}
              {displayData.businessAddress && (
                <div data-testid="text-business-address">{displayData.businessAddress}</div>
              )}
            </div>
          </div>

          {/* Receipt Info */}
          <div className="mb-6 text-sm">
            <div className="flex justify-between mb-2">
              <span className="font-medium">Receipt #:</span>
              <span data-testid="text-receipt-number">
                {generatedReceipt?.receiptNumber || "RCP-PREVIEW"}
              </span>
            </div>
            <div className="flex justify-between mb-2">
              <span className="font-medium">Date:</span>
              <span data-testid="text-receipt-date">{formatDate(currentDate)}</span>
            </div>
            <div className="flex justify-between mb-2">
              <span className="font-medium">Time:</span>
              <span data-testid="text-receipt-time">{formatTime(currentDate)}</span>
            </div>
            {displayData.customerName && (
              <div className="mt-3 pt-3 border-t border-border">
                <div className="flex justify-between">
                  <span className="font-medium">Customer:</span>
                  <span data-testid="text-customer-name">{displayData.customerName}</span>
                </div>
                {displayData.customerPhone && (
                  <div className="flex justify-between mt-1">
                    <span className="font-medium">Phone:</span>
                    <span data-testid="text-customer-phone">{displayData.customerPhone}</span>
                  </div>
                )}
                {displayData.customerEmail && (
                  <div className="flex justify-between mt-1">
                    <span className="font-medium">Email:</span>
                    <span data-testid="text-customer-email">{displayData.customerEmail}</span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Items List */}
          <div className="mb-6">
            <div className="border-b border-border pb-2 mb-3">
              <h3 className="font-semibold text-center">ITEMS</h3>
            </div>
            
            <div className="space-y-2 text-sm">
              {receiptData.items.length > 0 ? (
                receiptData.items.map((item, index) => (
                  <div key={item.id} data-testid={`receipt-item-${index}`}>
                    <div className="flex justify-between">
                      <span>{item.name || "Item"}</span>
                      <span>{formatCurrencyDisplay((item.price || 0) * (item.quantity || 1))}</span>
                    </div>
                    {(item.quantity || 1) > 1 && (
                      <div className="text-xs text-muted-foreground ml-2">
                        {item.quantity || 1} × {formatCurrencyDisplay(item.price || 0)}
                      </div>
                    )}
                  </div>
                ))
              ) : (
                <div className="text-center text-muted-foreground py-4">
                  No items added yet
                </div>
              )}
            </div>
          </div>

          {/* Totals */}
          <div className="border-t-2 border-border pt-3 mb-6">
            <div className="flex justify-between text-sm mb-2">
              <span>Subtotal:</span>
              <span data-testid="text-receipt-subtotal">{formatCurrencyDisplay(subtotal)}</span>
            </div>
            
            {discountAmount > 0 && (
              <div className="flex justify-between text-sm mb-2 text-green-600">
                <span>Discount:</span>
                <span data-testid="text-receipt-discount">-{formatCurrencyDisplay(discountAmount)}</span>
              </div>
            )}
            
            {taxAmount > 0 && (
              <div className="flex justify-between text-sm mb-2">
                <span>{country?.taxName || 'Tax'} ({receiptData.taxRate}%):</span>
                <span data-testid="text-receipt-tax">{formatCurrencyDisplay(taxAmount)}</span>
              </div>
            )}
            
            <div className="flex justify-between font-bold text-lg border-t border-border pt-2">
              <span>TOTAL:</span>
              <span data-testid="text-receipt-total">{formatCurrencyDisplay(totalAmount)}</span>
            </div>
          </div>

          {/* Notes */}
          {displayData.notes && (
            <div className="mb-6 text-sm border-t border-border pt-3">
              <div className="font-medium mb-1">Notes:</div>
              <div className="text-muted-foreground whitespace-pre-wrap" data-testid="text-receipt-notes">
                {displayData.notes}
              </div>
            </div>
          )}

          {/* QR Code */}
          {qrCode && (
            <div className="flex justify-center mb-6 no-print">
              <div className="text-center">
                <img src={qrCode} alt="Receipt QR Code" className="mx-auto mb-2" />
                <p className="text-xs text-muted-foreground">Scan to view receipt</p>
              </div>
            </div>
          )}

          {/* Payment Method */}
          <div className="text-center mb-6 text-sm">
            <div className="bg-muted p-2 rounded">
              <span className="font-medium">Payment Method: </span>
              <span data-testid="text-payment-method">
                {paymentMethodLabels[displayData.paymentMethod as keyof typeof paymentMethodLabels] || "Cash"}
              </span>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center text-xs text-muted-foreground border-t border-border pt-4">
            <div className="mb-2">Thank you for your business!</div>
            <div>Generated by Global Receipts</div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-center gap-3 mt-6 no-print">
          <Button 
            onClick={handlePrint}
            variant="secondary"
            className="bg-secondary hover:bg-secondary/90 text-secondary-foreground"
            data-testid="button-print-receipt"
          >
            <Printer className="mr-2 h-4 w-4" />
            Print
          </Button>
          
          {generatedReceipt && (
            <Button 
              onClick={handleShare}
              variant="default"
              data-testid="button-share-receipt"
            >
              <Share2 className="mr-2 h-4 w-4" />
              Share
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
