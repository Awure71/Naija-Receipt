# Overview

This is a global receipt generation web application built with React and Express that allows users to create professional receipts for businesses worldwide. The application features a modern interface for inputting business and customer information, adding items, and generating printable receipts with support for multiple currencies and countries. It's designed for small businesses and vendors who need to quickly generate receipts for transactions.

The app is now a Progressive Web App (PWA) that can be installed on Android phones and other devices, providing an app-like experience with offline capabilities.

## Recent Changes (October 2025)
- Enhanced dynamic item management:
  - Form now starts with one empty item row by default for better UX
  - Added duplicate item functionality allowing users to copy existing items with one click
  - Implemented toast notifications for user feedback when duplicating items
  - Improved item management UI with copy and delete buttons side-by-side
  - All item operations (add, duplicate, remove, quantity changes) trigger real-time calculation updates

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **React with TypeScript**: Modern component-based architecture using functional components and hooks
- **Vite Build System**: Fast development server and optimized production builds
- **UI Framework**: shadcn/ui component library built on top of Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming support
- **State Management**: React Hook Form for form handling, TanStack Query for server state
- **Routing**: Wouter for lightweight client-side routing

## Backend Architecture
- **Express.js Server**: RESTful API with TypeScript support
- **In-Memory Storage**: Currently uses a simple in-memory storage class for receipt data
- **Database Ready**: Drizzle ORM configured for PostgreSQL with migration support
- **Validation**: Zod schemas for request validation and type safety
- **Session Management**: PostgreSQL session store configured for future authentication

## Data Layer
- **Schema Design**: Centralized schema definitions in shared directory using Drizzle ORM
- **Type Safety**: End-to-end TypeScript types from database to frontend
- **Validation**: Zod schemas for runtime validation and type inference
- **Storage Interface**: Abstract storage interface allowing easy transition from memory to database

## Key Design Patterns
- **Monorepo Structure**: Client, server, and shared code in single repository
- **Shared Types**: Common types and schemas shared between frontend and backend
- **Component Composition**: Reusable UI components with consistent styling
- **Form Handling**: React Hook Form with Zod resolvers for validation
- **API Client**: Centralized API request handling with error management

## Development Environment
- **TypeScript Configuration**: Unified config supporting client, server, and shared code
- **Path Aliases**: Convenient imports using @ aliases for better code organization
- **Hot Reload**: Vite HMR for fast development iteration
- **Error Handling**: Runtime error overlay for development debugging

# External Dependencies

## Core Framework Dependencies
- **React 18**: Frontend framework with concurrent features
- **Express.js**: Backend web framework for Node.js
- **TypeScript**: Type safety across the entire application stack
- **Vite**: Build tool and development server

## UI and Styling
- **shadcn/ui**: Pre-built component library
- **Radix UI**: Headless UI primitives for accessibility
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library for consistent iconography

## Database and Validation
- **Drizzle ORM**: Type-safe SQL toolkit and query builder
- **@neondatabase/serverless**: PostgreSQL driver for serverless environments
- **Zod**: Schema validation library for TypeScript
- **connect-pg-simple**: PostgreSQL session store for Express

## State Management and Data Fetching
- **TanStack Query**: Server state management and caching
- **React Hook Form**: Form state management and validation
- **@hookform/resolvers**: Integration between React Hook Form and Zod

## Development Tools
- **tsx**: TypeScript execution environment for development
- **esbuild**: Fast JavaScript bundler for production builds
- **@replit/vite-plugin-runtime-error-modal**: Development error overlay
- **nanoid**: Unique ID generation for receipt numbers

## Utility Libraries
- **date-fns**: Date manipulation and formatting
- **clsx & tailwind-merge**: Conditional CSS class management
- **class-variance-authority**: Component variant management