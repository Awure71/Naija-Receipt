// Global configuration for countries and currencies
export interface Currency {
  code: string;
  symbol: string;
  name: string;
  decimals: number;
  stripeSupported: boolean;
}

export interface Country {
  code: string;
  name: string;
  currency: string;
  phonePrefix: string;
  locale: string;
  defaultTaxRate: number;
  taxName: string;
}

export const CURRENCIES: Record<string, Currency> = {
  USD: {
    code: "USD",
    symbol: "$",
    name: "US Dollar",
    decimals: 2,
    stripeSupported: true,
  },
  EUR: {
    code: "EUR",
    symbol: "€",
    name: "Euro",
    decimals: 2,
    stripeSupported: true,
  },
  GBP: {
    code: "GBP",
    symbol: "£",
    name: "British Pound",
    decimals: 2,
    stripeSupported: true,
  },
  NGN: {
    code: "NGN",
    symbol: "₦",
    name: "Nigerian Naira",
    decimals: 2,
    stripeSupported: true,
  },
  CAD: {
    code: "CAD",
    symbol: "C$",
    name: "Canadian Dollar",
    decimals: 2,
    stripeSupported: true,
  },
  AUD: {
    code: "AUD",
    symbol: "A$",
    name: "Australian Dollar",
    decimals: 2,
    stripeSupported: true,
  },
  JPY: {
    code: "JPY",
    symbol: "¥",
    name: "Japanese Yen",
    decimals: 0,
    stripeSupported: true,
  },
  CHF: {
    code: "CHF",
    symbol: "CHF",
    name: "Swiss Franc",
    decimals: 2,
    stripeSupported: true,
  },
  SEK: {
    code: "SEK",
    symbol: "kr",
    name: "Swedish Krona",
    decimals: 2,
    stripeSupported: true,
  },
  DKK: {
    code: "DKK",
    symbol: "kr",
    name: "Danish Krone",
    decimals: 2,
    stripeSupported: true,
  },
  NOK: {
    code: "NOK",
    symbol: "kr",
    name: "Norwegian Krone",
    decimals: 2,
    stripeSupported: true,
  },
  PLN: {
    code: "PLN",
    symbol: "zł",
    name: "Polish Złoty",
    decimals: 2,
    stripeSupported: true,
  },
  MXN: {
    code: "MXN",
    symbol: "$",
    name: "Mexican Peso",
    decimals: 2,
    stripeSupported: true,
  },
  BRL: {
    code: "BRL",
    symbol: "R$",
    name: "Brazilian Real",
    decimals: 2,
    stripeSupported: true,
  },
  HKD: {
    code: "HKD",
    symbol: "HK$",
    name: "Hong Kong Dollar",
    decimals: 2,
    stripeSupported: true,
  },
  SGD: {
    code: "SGD",
    symbol: "S$",
    name: "Singapore Dollar",
    decimals: 2,
    stripeSupported: true,
  },
  INR: {
    code: "INR",
    symbol: "₹",
    name: "Indian Rupee",
    decimals: 2,
    stripeSupported: true,
  },
  THB: {
    code: "THB",
    symbol: "฿",
    name: "Thai Baht",
    decimals: 2,
    stripeSupported: true,
  },
  MYR: {
    code: "MYR",
    symbol: "RM",
    name: "Malaysian Ringgit",
    decimals: 2,
    stripeSupported: true,
  },
  ZAR: {
    code: "ZAR",
    symbol: "R",
    name: "South African Rand",
    decimals: 2,
    stripeSupported: true,
  },
};

export const COUNTRIES: Record<string, Country> = {
  US: {
    code: "US",
    name: "United States",
    currency: "USD",
    phonePrefix: "+1",
    locale: "en-US",
    defaultTaxRate: 0,
    taxName: "Sales Tax",
  },
  GB: {
    code: "GB",
    name: "United Kingdom",
    currency: "GBP",
    phonePrefix: "+44",
    locale: "en-GB",
    defaultTaxRate: 20,
    taxName: "VAT",
  },
  CA: {
    code: "CA",
    name: "Canada",
    currency: "CAD",
    phonePrefix: "+1",
    locale: "en-CA",
    defaultTaxRate: 13,
    taxName: "GST/HST",
  },
  AU: {
    code: "AU",
    name: "Australia",
    currency: "AUD",
    phonePrefix: "+61",
    locale: "en-AU",
    defaultTaxRate: 10,
    taxName: "GST",
  },
  DE: {
    code: "DE",
    name: "Germany",
    currency: "EUR",
    phonePrefix: "+49",
    locale: "de-DE",
    defaultTaxRate: 19,
    taxName: "MwSt",
  },
  FR: {
    code: "FR",
    name: "France",
    currency: "EUR",
    phonePrefix: "+33",
    locale: "fr-FR",
    defaultTaxRate: 20,
    taxName: "TVA",
  },
  IT: {
    code: "IT",
    name: "Italy",
    currency: "EUR",
    phonePrefix: "+39",
    locale: "it-IT",
    defaultTaxRate: 22,
    taxName: "IVA",
  },
  ES: {
    code: "ES",
    name: "Spain",
    currency: "EUR",
    phonePrefix: "+34",
    locale: "es-ES",
    defaultTaxRate: 21,
    taxName: "IVA",
  },
  NL: {
    code: "NL",
    name: "Netherlands",
    currency: "EUR",
    phonePrefix: "+31",
    locale: "nl-NL",
    defaultTaxRate: 21,
    taxName: "BTW",
  },
  NG: {
    code: "NG",
    name: "Nigeria",
    currency: "NGN",
    phonePrefix: "+234",
    locale: "en-NG",
    defaultTaxRate: 7.5,
    taxName: "VAT",
  },
  ZA: {
    code: "ZA",
    name: "South Africa",
    currency: "ZAR",
    phonePrefix: "+27",
    locale: "en-ZA",
    defaultTaxRate: 15,
    taxName: "VAT",
  },
  JP: {
    code: "JP",
    name: "Japan",
    currency: "JPY",
    phonePrefix: "+81",
    locale: "ja-JP",
    defaultTaxRate: 10,
    taxName: "消費税",
  },
  CH: {
    code: "CH",
    name: "Switzerland",
    currency: "CHF",
    phonePrefix: "+41",
    locale: "de-CH",
    defaultTaxRate: 7.7,
    taxName: "MwSt",
  },
  SE: {
    code: "SE",
    name: "Sweden",
    currency: "SEK",
    phonePrefix: "+46",
    locale: "sv-SE",
    defaultTaxRate: 25,
    taxName: "Moms",
  },
  DK: {
    code: "DK",
    name: "Denmark",
    currency: "DKK",
    phonePrefix: "+45",
    locale: "da-DK",
    defaultTaxRate: 25,
    taxName: "Moms",
  },
  NO: {
    code: "NO",
    name: "Norway",
    currency: "NOK",
    phonePrefix: "+47",
    locale: "nb-NO",
    defaultTaxRate: 25,
    taxName: "MVA",
  },
  PL: {
    code: "PL",
    name: "Poland",
    currency: "PLN",
    phonePrefix: "+48",
    locale: "pl-PL",
    defaultTaxRate: 23,
    taxName: "VAT",
  },
  MX: {
    code: "MX",
    name: "Mexico",
    currency: "MXN",
    phonePrefix: "+52",
    locale: "es-MX",
    defaultTaxRate: 16,
    taxName: "IVA",
  },
  BR: {
    code: "BR",
    name: "Brazil",
    currency: "BRL",
    phonePrefix: "+55",
    locale: "pt-BR",
    defaultTaxRate: 17,
    taxName: "ICMS",
  },
  HK: {
    code: "HK",
    name: "Hong Kong",
    currency: "HKD",
    phonePrefix: "+852",
    locale: "en-HK",
    defaultTaxRate: 0,
    taxName: "Tax",
  },
  SG: {
    code: "SG",
    name: "Singapore",
    currency: "SGD",
    phonePrefix: "+65",
    locale: "en-SG",
    defaultTaxRate: 9,
    taxName: "GST",
  },
  IN: {
    code: "IN",
    name: "India",
    currency: "INR",
    phonePrefix: "+91",
    locale: "en-IN",
    defaultTaxRate: 18,
    taxName: "GST",
  },
  TH: {
    code: "TH",
    name: "Thailand",
    currency: "THB",
    phonePrefix: "+66",
    locale: "th-TH",
    defaultTaxRate: 7,
    taxName: "VAT",
  },
  MY: {
    code: "MY",
    name: "Malaysia",
    currency: "MYR",
    phonePrefix: "+60",
    locale: "en-MY",
    defaultTaxRate: 8,
    taxName: "SST",
  },
};

export const DEFAULT_COUNTRY = "US";
export const DEFAULT_CURRENCY = "USD";

export function formatCurrency(amount: number | string, currencyCode: string, locale?: string): string {
  const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
  const currency = CURRENCIES[currencyCode];
  
  if (!currency) {
    return `${currencyCode} ${numAmount.toFixed(2)}`;
  }

  const formatLocale = locale || "en-US";
  
  try {
    return new Intl.NumberFormat(formatLocale, {
      style: 'currency',
      currency: currencyCode,
      minimumFractionDigits: currency.decimals,
      maximumFractionDigits: currency.decimals,
    }).format(numAmount || 0);
  } catch (error) {
    // Fallback if locale is not supported
    return `${currency.symbol}${numAmount.toFixed(currency.decimals)}`;
  }
}

export function getCountryByCurrency(currencyCode: string): Country | undefined {
  return Object.values(COUNTRIES).find(country => country.currency === currencyCode);
}

export function getCurrencyByCountry(countryCode: string): Currency | undefined {
  const country = COUNTRIES[countryCode];
  return country ? CURRENCIES[country.currency] : undefined;
}