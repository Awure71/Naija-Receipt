import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { COUNTRIES, CURRENCIES } from "./global-config";

export const receipts = pgTable("receipts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  receiptNumber: text("receipt_number").notNull().unique(),
  businessName: text("business_name").notNull(),
  businessPhone: text("business_phone").notNull(),
  businessEmail: text("business_email"),
  businessAddress: text("business_address"),
  businessCountry: text("business_country").notNull().default("US"),
  customerName: text("customer_name"),
  customerPhone: text("customer_phone"),
  customerEmail: text("customer_email"),
  items: json("items").$type<ReceiptItem[]>().notNull(),
  currency: text("currency").notNull().default("USD"),
  subtotal: decimal("subtotal", { precision: 10, scale: 2 }).notNull(),
  taxRate: decimal("tax_rate", { precision: 5, scale: 2 }).default("0"),
  taxAmount: decimal("tax_amount", { precision: 10, scale: 2 }).default("0"),
  discountType: text("discount_type").default("none"),
  discountValue: decimal("discount_value", { precision: 10, scale: 2 }).default("0"),
  discountAmount: decimal("discount_amount", { precision: 10, scale: 2 }).default("0"),
  total: decimal("total", { precision: 10, scale: 2 }).notNull(),
  notes: text("notes"),
  paymentMethod: text("payment_method").notNull(),
  paymentStatus: text("payment_status").notNull().default("pending"),
  stripePaymentIntentId: text("stripe_payment_intent_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const receiptItemSchema = z.object({
  id: z.string(),
  name: z.string().min(1, "Item name is required"),
  price: z.number().min(0, "Price must be positive"),
  quantity: z.number().min(1, "Quantity must be at least 1").default(1),
});

export const insertReceiptSchema = createInsertSchema(receipts, {
  businessName: z.string().min(1, "Business name is required"),
  businessPhone: z.string().min(1, "Business phone is required"),
  businessEmail: z.string().email().optional().or(z.literal("")),
  businessAddress: z.string().optional(),
  businessCountry: z.string().refine((val) => val in COUNTRIES, "Invalid country code"),
  customerName: z.string().optional(),
  customerPhone: z.string().optional(),
  customerEmail: z.string().email().optional().or(z.literal("")),
  currency: z.string().refine((val) => val in CURRENCIES, "Invalid currency code"),
  items: z.array(receiptItemSchema).min(1, "At least one item is required"),
  subtotal: z.string().or(z.number()),
  taxRate: z.string().or(z.number()).optional(),
  taxAmount: z.string().or(z.number()).optional(),
  discountType: z.enum(["none", "percentage", "fixed"]).optional(),
  discountValue: z.string().or(z.number()).optional(),
  discountAmount: z.string().or(z.number()).optional(),
  total: z.string().or(z.number()),
  notes: z.string().optional(),
  paymentMethod: z.enum(["cash", "bank_transfer", "pos", "mobile_money", "stripe"]),
  paymentStatus: z.enum(["pending", "paid", "failed", "refunded"]),
}).omit({
  id: true,
  receiptNumber: true,
  createdAt: true,
  stripePaymentIntentId: true,
});

export type ReceiptItem = z.infer<typeof receiptItemSchema>;
export type InsertReceipt = z.infer<typeof insertReceiptSchema>;
export type Receipt = typeof receipts.$inferSelect;
