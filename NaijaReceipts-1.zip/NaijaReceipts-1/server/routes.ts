import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { insertReceiptSchema } from "@shared/schema";
import { CURRENCIES } from "@shared/global-config";
import { z } from "zod";

// Stripe configuration
const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;

export async function registerRoutes(app: Express): Promise<Server> {
  // Create a new receipt
  app.post("/api/receipts", async (req, res) => {
    try {
      const validatedData = insertReceiptSchema.parse(req.body);
      const receipt = await storage.createReceipt(validatedData);
      res.json(receipt);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  // Get receipt by ID
  app.get("/api/receipts/:id", async (req, res) => {
    try {
      const receipt = await storage.getReceipt(req.params.id);
      if (!receipt) {
        res.status(404).json({ message: "Receipt not found" });
        return;
      }
      res.json(receipt);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get all receipts
  app.get("/api/receipts", async (req, res) => {
    try {
      const receipts = await storage.getAllReceipts();
      res.json(receipts);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Create payment intent for Stripe payments
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      if (!stripe) {
        return res.status(500).json({ message: "Stripe not configured" });
      }

      const { amount, currency, receiptId } = req.body;
      
      if (!amount || !currency) {
        return res.status(400).json({ message: "Amount and currency are required" });
      }

      const currencyInfo = CURRENCIES[currency];
      if (!currencyInfo || !currencyInfo.stripeSupported) {
        return res.status(400).json({ message: "Currency not supported" });
      }

      // Convert amount to smallest currency unit (cents)
      const amountInCents = Math.round(parseFloat(amount) * Math.pow(10, currencyInfo.decimals));

      const paymentIntent = await stripe.paymentIntents.create({
        amount: amountInCents,
        currency: currency.toLowerCase(),
        metadata: receiptId ? { receiptId } : {},
        automatic_payment_methods: {
          enabled: true,
        },
      });

      res.json({ 
        clientSecret: paymentIntent.client_secret,
        paymentIntentId: paymentIntent.id 
      });
    } catch (error: any) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ 
        message: "Error creating payment intent", 
        error: error.message 
      });
    }
  });

  // Update receipt payment status
  app.patch("/api/receipts/:id/payment", async (req, res) => {
    try {
      const { id } = req.params;
      const { paymentStatus, stripePaymentIntentId } = req.body;
      
      const updatedReceipt = await storage.updateReceiptPaymentStatus(
        id, 
        paymentStatus, 
        stripePaymentIntentId
      );
      
      if (!updatedReceipt) {
        return res.status(404).json({ message: "Receipt not found" });
      }
      
      res.json(updatedReceipt);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
