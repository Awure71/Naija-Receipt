import { useState, useEffect } from "react";
import { WifiOff, Wifi } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function OfflineIndicator() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showOffline, setShowOffline] = useState(!navigator.onLine);
  const [showOnline, setShowOnline] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setShowOffline(false);
      setShowOnline(true);
      setTimeout(() => setShowOnline(false), 3000);
    };

    const handleOffline = () => {
      setIsOnline(false);
      setShowOffline(true);
      setShowOnline(false);
    };

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  if (!showOffline && !showOnline) {
    return null;
  }

  return (
    <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 animate-in slide-in-from-top duration-300">
      <Card className={`${!isOnline ? 'border-destructive bg-destructive/10' : 'border-green-500 bg-green-500/10'} shadow-lg`}>
        <CardContent className="p-3 px-4">
          <div className="flex items-center gap-2">
            {!isOnline ? (
              <>
                <WifiOff className="h-5 w-5 text-destructive" />
                <span className="text-sm font-medium text-destructive" data-testid="text-offline">
                  You're offline
                </span>
              </>
            ) : (
              <>
                <Wifi className="h-5 w-5 text-green-600" />
                <span className="text-sm font-medium text-green-600" data-testid="text-online">
                  Back online
                </span>
              </>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
