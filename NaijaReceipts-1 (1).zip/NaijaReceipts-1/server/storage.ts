import { type Receipt, type InsertReceipt } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getReceipt(id: string): Promise<Receipt | undefined>;
  getReceiptByNumber(receiptNumber: string): Promise<Receipt | undefined>;
  createReceipt(receipt: InsertReceipt): Promise<Receipt>;
  updateReceiptPaymentStatus(id: string, paymentStatus: string, stripePaymentIntentId?: string): Promise<Receipt | undefined>;
  getAllReceipts(): Promise<Receipt[]>;
}

export class MemStorage implements IStorage {
  private receipts: Map<string, Receipt>;

  constructor() {
    this.receipts = new Map();
  }

  async getReceipt(id: string): Promise<Receipt | undefined> {
    return this.receipts.get(id);
  }

  async getReceiptByNumber(receiptNumber: string): Promise<Receipt | undefined> {
    return Array.from(this.receipts.values()).find(
      (receipt) => receipt.receiptNumber === receiptNumber,
    );
  }

  async createReceipt(insertReceipt: InsertReceipt): Promise<Receipt> {
    const id = randomUUID();
    const receiptNumber = this.generateReceiptNumber();
    const createdAt = new Date();
    
    const receipt: Receipt = { 
      ...insertReceipt, 
      id, 
      receiptNumber,
      createdAt,
      subtotal: insertReceipt.subtotal.toString(),
      total: insertReceipt.total.toString(),
      businessEmail: insertReceipt.businessEmail || null,
      businessAddress: insertReceipt.businessAddress || null,
      customerName: insertReceipt.customerName || null,
      customerPhone: insertReceipt.customerPhone || null,
      customerEmail: insertReceipt.customerEmail || null,
      stripePaymentIntentId: null,
    };
    
    this.receipts.set(id, receipt);
    return receipt;
  }

  async updateReceiptPaymentStatus(id: string, paymentStatus: string, stripePaymentIntentId?: string): Promise<Receipt | undefined> {
    const receipt = this.receipts.get(id);
    if (!receipt) return undefined;
    
    const updatedReceipt: Receipt = {
      ...receipt,
      paymentStatus,
      stripePaymentIntentId: stripePaymentIntentId || receipt.stripePaymentIntentId,
    };
    
    this.receipts.set(id, updatedReceipt);
    return updatedReceipt;
  }

  async getAllReceipts(): Promise<Receipt[]> {
    return Array.from(this.receipts.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  private generateReceiptNumber(): string {
    const now = new Date();
    const year = now.getFullYear();
    const month = (now.getMonth() + 1).toString().padStart(2, '0');
    const day = now.getDate().toString().padStart(2, '0');
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `RCP-${year}${month}${day}-${random}`;
  }
}

export const storage = new MemStorage();
